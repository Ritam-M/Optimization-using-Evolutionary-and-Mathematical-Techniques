function g = G7(x)
   g= x(1)-100 ;
end