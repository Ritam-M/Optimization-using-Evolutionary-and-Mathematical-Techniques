function g = G17(x)
   g= 10000-x(3);
end