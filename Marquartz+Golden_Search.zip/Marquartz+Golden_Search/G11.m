function g = G11(x)
   g= x(5)-10 ;
end