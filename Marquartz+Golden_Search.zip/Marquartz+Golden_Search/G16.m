function g = G16(x)
   g= 10000-x(2);
end