function g = G21(x)
   g= 1000-x(7);
end