function g = G9(x)
   g= x(3)-1000 ;
end