function g = G20(x)
   g= 1000-x(6);
end