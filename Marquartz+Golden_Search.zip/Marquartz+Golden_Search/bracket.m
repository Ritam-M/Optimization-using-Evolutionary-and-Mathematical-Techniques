function b = bracket(x)
if (x<0)
    b=x;
else
    b=0;
end
end