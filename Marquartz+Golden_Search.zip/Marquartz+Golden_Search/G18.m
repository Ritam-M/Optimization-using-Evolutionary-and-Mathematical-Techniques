function g = G18(x)
   g= 1000-x(4);
end