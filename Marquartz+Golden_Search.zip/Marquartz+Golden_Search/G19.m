function g = G19(x)
   g= 1000-x(5);
end