function g = G22(x)
   g= 1000-x(8);
end