function g = G12(x)
   g= x(6)-10 ;
end