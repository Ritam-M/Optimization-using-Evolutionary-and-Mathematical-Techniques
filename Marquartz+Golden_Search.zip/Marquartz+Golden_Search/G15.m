function g = G15(x)
   g= 10000-x(1);
end