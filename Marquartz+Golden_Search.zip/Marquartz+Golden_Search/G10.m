function g = G10(x)
   g= x(4)-10 ;
end