function g = G13(x)
   g= x(7)-10 ;
end