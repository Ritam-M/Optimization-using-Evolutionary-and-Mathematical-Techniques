function g = G14(x)
   g= x(8)-10 ;
end