function g = G8(x)
   g= x(2)-1000 ;
end